﻿using EnerGym.Data.Models;
using EnerGym.Services.Data.Interfaces;

namespace EnerGym.Services.Data.Implementations
{
    public class WorkoutService : IWorkoutSevice
    {
        public Task CreateAsync()
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync()
        {
            throw new NotImplementedException();
        }

        public Task EditAsync()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<WorkoutPlan>> GetAllAsync()
        {
            throw new NotImplementedException();
        }
    }
}
