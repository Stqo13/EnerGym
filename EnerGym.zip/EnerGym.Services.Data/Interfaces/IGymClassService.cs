﻿namespace EnerGym.Services.Data.Interfaces
{
    public interface IGymClassService
    {
        //public async Task<IEnumerable<>>
    }
}
