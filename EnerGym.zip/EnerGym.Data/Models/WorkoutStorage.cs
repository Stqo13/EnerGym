﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace EnerGym.Data.Models
{
    public class WorkoutStorage
    {
        [Comment("Workout Storage Identitfier")]
        [Key]
        public int Id { get; set; }

        public ICollection<WorkoutPlan> WorkoutPlans { get; set; }
            = new List<WorkoutPlan>();  
    }
}
