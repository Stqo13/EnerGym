﻿namespace EnerGym.Data.Models.Enums
{
    public enum PlanType
    {
        Standart,
        Premium,
        VIP,
        ClassOnly,
        Student,
        Senior
    }
}
