﻿namespace EnerGym.ViewModels.WorkoutRoutineViewModels
{
    public class WorkoutRoutineSelectViewModel
    {
        public int Id { get; set; }

        public required string ExerciseName { get; set; } = null!;
    }
}
